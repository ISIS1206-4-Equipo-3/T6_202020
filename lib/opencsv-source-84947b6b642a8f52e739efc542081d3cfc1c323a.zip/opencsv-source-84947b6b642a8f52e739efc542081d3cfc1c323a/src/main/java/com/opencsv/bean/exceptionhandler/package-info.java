/**
 * This package contains the interface and standard implementations for
 * exception handling logic during bean creation and bean writing.
 */
package com.opencsv.bean.exceptionhandler;