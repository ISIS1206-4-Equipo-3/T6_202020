/** This is a package of utility classes for internal use. */
package com.opencsv.bean.util;