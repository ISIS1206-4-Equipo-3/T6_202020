package com.opencsv.bean.mocks.recurse;

import com.opencsv.bean.CsvRecurse;

public class CharacterRecurse {
    @CsvRecurse
    public char c;
}
