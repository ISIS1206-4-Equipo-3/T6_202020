package com.opencsv.bean.mocks.recurse;

import com.opencsv.bean.CsvRecurse;

public class LongRecurse {
    @CsvRecurse
    public long l;
}
