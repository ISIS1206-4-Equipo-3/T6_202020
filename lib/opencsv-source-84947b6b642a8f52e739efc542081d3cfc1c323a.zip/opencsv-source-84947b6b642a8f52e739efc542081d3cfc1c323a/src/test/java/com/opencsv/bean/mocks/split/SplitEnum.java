package com.opencsv.bean.mocks.split;

public enum SplitEnum {
    SPLIT1, Split2, split3;
}
